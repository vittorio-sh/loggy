/**
 *
 */
package com.algonquin.loggy;

/**
 * @author jesus
 *
 */
public interface Processable {

    public void postProcess();
}
